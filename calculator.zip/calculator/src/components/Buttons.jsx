import styles from "./Buttons.module.css";
import PropTypes from "prop-types";

const Buttons = ({ onButtonClick }) => {
  const buttonName = ['C', '1', '2', '-', '3', '4', '5', '+', '7', '8', '9', '/', '0', '=', '*', '*', '.'];

  return (
    <>
      <div className={styles.buttonsContainer}>
        {buttonName.map((button, index) => (
          <button key={index} className={styles.button} onClick={() => onButtonClick(button)}>
            {button}
          </button>
        ))}
      </div>
    </>
  );
};

Buttons.propTypes = {
  onButtonClick: PropTypes.func.isRequired,
};

export default Buttons;
